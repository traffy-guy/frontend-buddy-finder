# BuddyFinder — Deployment Guide

## What changed in Chat.tsx
- Connected to real MongoDB backend via REST API
- Real-time messages via Socket.io
- Real inbox loaded from /api/chat/inbox
- Real message history from /api/chat/history/:userId
- Typing indicators wired to socket events
- Online/offline presence via socket
- Optimistic message bubbles (appear instantly, confirmed on delivery)
- Multi-language support preserved exactly as before

## Step 1 — Add files to your GitHub repo

Upload these files to your GitHub repo (github.com/j0996196-coder/buddyfinder):
- src/Chat.tsx        ← replace your existing one
- src/api.ts          ← new file
- package.json        ← replace existing (adds socket.io-client)
- vite.config.ts      ← replace existing
- netlify.toml        ← new file
- .env.example        ← new file

## Step 2 — Deploy backend on Render

1. Upload the activityhub-backend files to a NEW GitHub repo
   e.g. github.com/j0996196-coder/buddyfinder-api
   Upload files DIRECTLY to root (no subfolder!)

2. Go to render.com → New Web Service → connect buddyfinder-api repo
   - Build Command:  npm install
   - Start Command:  node server.js
   - Root Directory: (leave EMPTY)

3. Add environment variables in Render:
   MONGO_URI           = (from MongoDB Atlas)
   JWT_SECRET          = any_random_secret_string
   JWT_EXPIRES_IN      = 7d
   CLOUDINARY_CLOUD_NAME = (from cloudinary.com)
   CLOUDINARY_API_KEY  = (from cloudinary.com)
   CLOUDINARY_API_SECRET = (from cloudinary.com)
   TWILIO_ACCOUNT_SID  = (from twilio.com)
   TWILIO_AUTH_TOKEN   = (from twilio.com)
   TWILIO_VERIFY_SID   = (from twilio.com)
   FRONTEND_URL        = https://your-netlify-url.netlify.app

4. Deploy → you get URL like https://buddyfinder-api.onrender.com

## Step 3 — Set env variable in Netlify

1. Go to Netlify → your site → Site Settings → Environment Variables
2. Add:
   Key:   VITE_API_URL
   Value: https://buddyfinder-api.onrender.com

3. Trigger a redeploy → Netlify → Deploys → Trigger deploy

## Step 4 — Done!

Your app is now fully live with:
- Real authentication (email + phone OTP)
- Real-time chat (Socket.io)
- Nearby people (MongoDB geo queries)
- Profile photos (Cloudinary)
- All 9 Indian language translations
