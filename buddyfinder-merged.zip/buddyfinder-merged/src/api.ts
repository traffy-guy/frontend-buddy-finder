// src/api.ts — All backend calls in one place
const API = import.meta.env.VITE_API_URL || "http://localhost:5000";

export { API };

function getToken() { return localStorage.getItem("bf_token"); }
export const setToken  = (t: string) => localStorage.setItem("bf_token", t);
export const clearToken = () => localStorage.removeItem("bf_token");

export async function apiFetch(method: string, path: string, body?: object) {
  const headers: Record<string,string> = { "Content-Type": "application/json" };
  const token = getToken();
  if (token) headers["Authorization"] = `Bearer ${token}`;
  const res = await fetch(`${API}${path}`, {
    method, headers,
    body: body ? JSON.stringify(body) : undefined,
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || "Request failed");
  return data;
}

// ── AUTH ──────────────────────────────────────────────────────────
export const auth = {
  signup: (name: string, email: string, password: string, phone: string, gender: string) =>
    apiFetch("POST", "/api/auth/signup", { name, email, password, phone, gender }),
  login:  (email: string, password: string) =>
    apiFetch("POST", "/api/auth/login", { email, password }),
  sendOTP:   (phone: string) => apiFetch("POST", "/api/auth/phone/send-otp", { phone }),
  verifyOTP: (phone: string, otp: string, name?: string, gender?: string) =>
    apiFetch("POST", "/api/auth/phone/verify-otp", { phone, otp, name, gender }),
  me: () => apiFetch("GET", "/api/auth/me"),
};

// ── USERS ─────────────────────────────────────────────────────────
export const users = {
  nearby:         (radius = 10, activity = "") =>
    apiFetch("GET", `/api/users/nearby?radius=${radius}${activity ? `&activity=${encodeURIComponent(activity)}` : ""}`),
  getById:        (id: string)   => apiFetch("GET",  `/api/users/${id}`),
  updateProfile:  (data: object) => apiFetch("PUT",  "/api/users/profile", data),
  updateLocation: (lat: number, lng: number, city: string) =>
    apiFetch("PUT", "/api/users/location", { latitude: lat, longitude: lng, city }),
};

// ── CONNECTIONS ───────────────────────────────────────────────────
export const connections = {
  sendRequest: (toId: string)    => apiFetch("POST",   `/api/connections/request/${toId}`),
  incoming:    ()                => apiFetch("GET",    "/api/connections/requests/incoming"),
  accept:      (reqId: string)   => apiFetch("PUT",    `/api/connections/accept/${reqId}`),
  reject:      (reqId: string)   => apiFetch("PUT",    `/api/connections/reject/${reqId}`),
  friends:     ()                => apiFetch("GET",    "/api/connections/friends"),
  remove:      (id: string)      => apiFetch("DELETE", `/api/connections/${id}`),
};

// ── CHAT ──────────────────────────────────────────────────────────
export const chat = {
  inbox:   ()           => apiFetch("GET", "/api/chat/inbox"),
  history: (uid: string, page = 1) => apiFetch("GET", `/api/chat/history/${uid}?page=${page}`),
  unread:  ()           => apiFetch("GET", "/api/chat/unread"),
};
