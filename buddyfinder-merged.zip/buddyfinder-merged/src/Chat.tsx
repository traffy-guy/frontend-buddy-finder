import { useState, useEffect, useRef } from "react";
import { useNavigate, useParams } from "react-router";
import { ArrowLeft, Send, User, MoreVertical, Phone, Video, Globe, Users } from "lucide-react";
import { io, Socket } from "socket.io-client";

// ── CONFIG — change this to your Render URL after deploying ──────
const API = import.meta.env.VITE_API_URL || "http://localhost:5000";

// ── LANGUAGE TRANSLATIONS ────────────────────────────────────────
const translations = {
  en: { buddyFinder:"Buddy Finder", messages:"Messages", unread:"unread", online:"Online", offline:"Offline", typeMessage:"Type a message...", selectLanguage:"Select Language", noMessages:"No messages yet" },
  hi: { buddyFinder:"बडी फाइंडर", messages:"संदेश", unread:"अपढ़े", online:"ऑनलाइन", offline:"ऑफलाइन", typeMessage:"संदेश लिखें...", selectLanguage:"भाषा चुनें", noMessages:"अभी कोई संदेश नहीं" },
  ta: { buddyFinder:"பட்டி ஃபைண்டர்", messages:"செய்திகள்", unread:"வாசிக்காதவை", online:"ஆன்லைன்", offline:"ஆஃப்லைன்", typeMessage:"செய்தி தட்டச்சு செய்யவும்...", selectLanguage:"மொழி தேர்ந்தெடுக்கவும்", noMessages:"இதுவரை செய்திகள் இல்லை" },
  te: { buddyFinder:"బడ్డీ ఫైండర్", messages:"సందేశాలు", unread:"చదవని", online:"ఆన్‌లైన్", offline:"ఆఫ్‌లైన్", typeMessage:"సందేశం టైప్ చేయండి...", selectLanguage:"భాషను ఎంచుకోండి", noMessages:"ఇంకా సందేశాలు లేవు" },
  kn: { buddyFinder:"ಬಡ್ಡಿ ಫೈಂಡರ್", messages:"ಸಂದೇಶಗಳು", unread:"ಓದದ", online:"ಆನ್‌ಲೈನ್", offline:"ಆಫ್‌ಲೈನ್", typeMessage:"ಸಂದೇಶ ಟೈಪ್ ಮಾಡಿ...", selectLanguage:"ಭಾಷೆ ಆಯ್ಕೆ ಮಾಡಿ", noMessages:"ಇನ್ನೂ ಸಂದೇಶಗಳಿಲ್ಲ" },
  ml: { buddyFinder:"ബഡി ഫൈൻഡർ", messages:"സന്ദേശങ്ങൾ", unread:"വായിക്കാത്തത്", online:"ഓൺലൈൻ", offline:"ഓഫ്‌ലൈൻ", typeMessage:"സന്ദേശം ടൈപ്പ് ചെയ്യുക...", selectLanguage:"ഭാഷ തിരഞ്ഞെടുക്കുക", noMessages:"ഇതുവരെ സന്ദേശങ്ങളില്ല" },
  gu: { buddyFinder:"બડી ફાઇન્ડર", messages:"સંદેશ", unread:"વાંચ્યા", online:"ઑનલાઇન", offline:"ઑફલાઇન", typeMessage:"સંદેશ લખો...", selectLanguage:"ભાષા પસંદ કરો", noMessages:"હજી કોઈ સંદેશ નથી" },
  mr: { buddyFinder:"बडी फाइंडर", messages:"संदेश", unread:"अवाचित", online:"ऑनलाइन", offline:"ऑफलाइन", typeMessage:"संदेश लिहा...", selectLanguage:"भाषा निवडा", noMessages:"अजून कोणतेही संदेश नाहीत" },
  pa: { buddyFinder:"ਬਡੀ ਫਾਈਂਡਰ", messages:"ਸੁਨੇਹੇ", unread:"ਨਾ ਪੜ੍ਹੇ", online:"ਆਨਲਾਈਨ", offline:"ਆਫਲਾਈਨ", typeMessage:"ਸੁਨੇਹਾ ਲਿਖੋ...", selectLanguage:"ਭਾਸ਼ਾ ਚੁਣੋ", noMessages:"ਅਜੇ ਕੋਈ ਸੁਨੇਹੇ ਨਹੀਂ" },
};

const languages = [
  { code:"en", name:"English", flag:"🇬🇧" },
  { code:"hi", name:"हिंदी", flag:"🇮🇳" },
  { code:"ta", name:"தமிழ்", flag:"🇮🇳" },
  { code:"te", name:"తెలుగు", flag:"🇮🇳" },
  { code:"kn", name:"ಕನ್ನಡ", flag:"🇮🇳" },
  { code:"ml", name:"മലയാളം", flag:"🇮🇳" },
  { code:"gu", name:"ગુજરાતી", flag:"🇮🇳" },
  { code:"mr", name:"मराठी", flag:"🇮🇳" },
  { code:"pa", name:"ਪੰਜਾਬੀ", flag:"🇮🇳" },
];

const BuddyFinderLogo = ({ size = "md" }: { size?: "sm"|"md"|"lg" }) => {
  const s = { sm:"w-8 h-8", md:"w-12 h-12", lg:"w-16 h-16" };
  return (
    <div className={`${s[size]} rounded-full bg-gradient-to-br from-emerald-500 to-teal-600 flex items-center justify-center shadow-lg`}>
      <Users className="w-1/2 h-1/2 text-white" />
    </div>
  );
};

// ── HTTP HELPER ──────────────────────────────────────────────────
async function apiFetch(method: string, path: string, body?: object) {
  const token = localStorage.getItem("bf_token");
  const headers: Record<string,string> = { "Content-Type": "application/json" };
  if (token) headers["Authorization"] = `Bearer ${token}`;
  const res = await fetch(`${API}${path}`, {
    method, headers,
    body: body ? JSON.stringify(body) : undefined,
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || "Request failed");
  return data;
}

// ── SOCKET SINGLETON ─────────────────────────────────────────────
let socketInstance: Socket | null = null;
function getSocket(): Socket | null {
  const token = localStorage.getItem("bf_token");
  if (!token) return null;
  if (!socketInstance) {
    socketInstance = io(API, { auth: { token } });
  }
  return socketInstance;
}

// ── MESSAGE TYPE ─────────────────────────────────────────────────
interface Message {
  _id?: string;
  text: string;
  from: string;
  to: string;
  createdAt?: string;
  optimistic?: boolean;
}

interface Conversation {
  other: { _id: string; name: string; photoURL?: string; city?: string };
  lastMsg: { text: string; from: string; createdAt: string };
  unread: number;
}

export default function Chat() {
  const navigate = useNavigate();
  const { userId } = useParams();
  const [message, setMessage]           = useState("");
  const [language, setLanguage]         = useState<keyof typeof translations>(
    (localStorage.getItem("preferredLanguage") as keyof typeof translations) || "en"
  );
  const [showLangMenu, setShowLangMenu] = useState(false);
  const [inbox, setInbox]               = useState<Conversation[]>([]);
  const [messages, setMessages]         = useState<Message[]>([]);
  const [peerOnline, setPeerOnline]     = useState(false);
  const [typing, setTyping]             = useState(false);
  const [loading, setLoading]           = useState(false);
  const [myId, setMyId]                 = useState<string>("");
  const [peerName, setPeerName]         = useState("");
  const messagesEnd = useRef<HTMLDivElement>(null);
  const typingTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const t = translations[language];

  // ── GET MY ID ──────────────────────────────────────────────────
  useEffect(() => {
    apiFetch("GET", "/api/auth/me")
      .then(u => setMyId(u._id))
      .catch(() => navigate("/login"));
  }, []);

  // ── LOAD INBOX ─────────────────────────────────────────────────
  useEffect(() => {
    if (userId) return;
    setLoading(true);
    apiFetch("GET", "/api/chat/inbox")
      .then(setInbox)
      .catch(console.error)
      .finally(() => setLoading(false));
  }, [userId]);

  // ── LOAD HISTORY ───────────────────────────────────────────────
  useEffect(() => {
    if (!userId) return;
    setLoading(true);
    apiFetch("GET", `/api/chat/history/${userId}`)
      .then(msgs => { setMessages(msgs); scrollBottom(); })
      .catch(console.error)
      .finally(() => setLoading(false));

    // Get peer name from inbox or fetch profile
    apiFetch("GET", `/api/users/${userId}`)
      .then(u => setPeerName(u.name))
      .catch(() => setPeerName("User"));
  }, [userId]);

  // ── SOCKET EVENTS ──────────────────────────────────────────────
  useEffect(() => {
    const socket = getSocket();
    if (!socket) return;

    socket.on("message:receive", (msg: Message) => {
      if (msg.from === userId) {
        setMessages(prev => [...prev.filter(m => !m.optimistic), msg]);
        scrollBottom();
        socket.emit("message:read", { fromId: userId });
      }
    });

    socket.on("message:sent", (msg: Message) => {
      setMessages(prev => [...prev.filter(m => !m.optimistic), msg]);
      scrollBottom();
    });

    socket.on("typing:start", ({ fromId }: { fromId: string }) => {
      if (fromId === userId) setTyping(true);
    });
    socket.on("typing:stop", ({ fromId }: { fromId: string }) => {
      if (fromId === userId) setTyping(false);
    });

    socket.on("user:online",  ({ userId: uid }: { userId: string }) => { if (uid === userId) setPeerOnline(true); });
    socket.on("user:offline", ({ userId: uid }: { userId: string }) => { if (uid === userId) setPeerOnline(false); });

    return () => {
      socket.off("message:receive");
      socket.off("message:sent");
      socket.off("typing:start");
      socket.off("typing:stop");
      socket.off("user:online");
      socket.off("user:offline");
    };
  }, [userId]);

  const scrollBottom = () => setTimeout(() => messagesEnd.current?.scrollIntoView({ behavior: "smooth" }), 50);

  // ── SEND MESSAGE ───────────────────────────────────────────────
  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    const text = message.trim();
    if (!text || !userId) return;
    setMessage("");

    // Optimistic bubble
    const optimistic: Message = { text, from: myId, to: userId, optimistic: true };
    setMessages(prev => [...prev, optimistic]);
    scrollBottom();

    const socket = getSocket();
    if (socket) {
      socket.emit("message:send", { toId: userId, text });
    } else {
      // Fallback: REST
      apiFetch("POST", `/api/chat/send`, { toId: userId, text }).catch(console.error);
    }
  };

  // ── TYPING INDICATOR ───────────────────────────────────────────
  const handleTyping = (e: React.ChangeEvent<HTMLInputElement>) => {
    setMessage(e.target.value);
    const socket = getSocket();
    if (!socket || !userId) return;
    socket.emit("typing:start", { toId: userId });
    if (typingTimer.current) clearTimeout(typingTimer.current);
    typingTimer.current = setTimeout(() => socket.emit("typing:stop", { toId: userId }), 1500);
  };

  const handleLangChange = (lang: keyof typeof translations) => {
    setLanguage(lang);
    localStorage.setItem("preferredLanguage", lang);
    setShowLangMenu(false);
  };

  // ════════════════════════════════════════════════════════════════
  // INBOX VIEW
  // ════════════════════════════════════════════════════════════════
  if (!userId) {
    return (
      <div className="min-h-screen bg-slate-50">
        <div className="bg-gradient-to-r from-emerald-600 to-teal-600 text-white sticky top-0 z-20">
          <div className="max-w-7xl mx-auto px-4 py-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <button onClick={() => navigate("/home")} className="p-2 hover:bg-white/20 rounded-full transition-colors">
                  <ArrowLeft className="w-6 h-6" />
                </button>
                <div className="flex items-center gap-3">
                  <BuddyFinderLogo size="md" />
                  <div>
                    <h1 className="text-xl font-bold">{t.buddyFinder}</h1>
                    <p className="text-white/90 text-sm">{inbox.filter(c => c.unread > 0).length} {t.messages}</p>
                  </div>
                </div>
              </div>

              {/* Language Selector */}
              <div className="relative">
                <button onClick={() => setShowLangMenu(!showLangMenu)} className="p-2 hover:bg-white/20 rounded-full transition-colors flex items-center gap-2">
                  <Globe className="w-6 h-6" />
                  <span className="text-sm">{languages.find(l => l.code === language)?.flag}</span>
                </button>
                {showLangMenu && (
                  <div className="absolute right-0 mt-2 bg-white rounded-lg shadow-lg overflow-hidden z-30 min-w-[200px]">
                    {languages.map(lang => (
                      <button key={lang.code} onClick={() => handleLangChange(lang.code as keyof typeof translations)}
                        className={`w-full flex items-center gap-3 px-4 py-3 hover:bg-slate-100 transition-colors text-left ${language === lang.code ? "bg-emerald-100 text-emerald-700" : "text-gray-900"}`}>
                        <span className="text-lg">{lang.flag}</span>
                        <span className="text-sm font-medium">{lang.name}</span>
                      </button>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>

        <div className="max-w-4xl mx-auto px-4 py-8">
          <div className="bg-white rounded-2xl shadow-sm p-8 text-center mb-6">
            <BuddyFinderLogo size="lg" />
            <h2 className="text-2xl font-bold text-gray-900 mt-4">{t.buddyFinder}</h2>
            <p className="text-gray-600 mt-2">Find your perfect activity buddy!</p>
          </div>
        </div>

        <div className="max-w-4xl mx-auto px-4 pb-6">
          <div className="bg-white rounded-2xl shadow-sm overflow-hidden">
            {loading && <div className="p-8 text-center text-gray-400">Loading...</div>}
            {!loading && inbox.length === 0 && (
              <div className="p-8 text-center text-gray-400">{t.noMessages}</div>
            )}
            {inbox.map(conv => (
              <button key={conv.other._id} onClick={() => navigate(`/chat/${conv.other._id}`)}
                className="w-full flex items-center gap-4 p-4 hover:bg-slate-50 transition-colors border-b border-gray-100 last:border-b-0">
                <div className="relative flex-shrink-0">
                  {conv.other.photoURL
                    ? <img src={conv.other.photoURL} className="w-14 h-14 rounded-full object-cover" />
                    : <div className="w-14 h-14 rounded-full bg-gradient-to-br from-emerald-400 to-teal-500 flex items-center justify-center"><User className="w-7 h-7 text-white" /></div>
                  }
                </div>
                <div className="flex-1 text-left min-w-0">
                  <div className="flex items-center justify-between mb-1">
                    <h3 className="font-semibold text-gray-900 truncate">{conv.other.name}</h3>
                    <span className="text-xs text-gray-500 flex-shrink-0 ml-2">
                      {new Date(conv.lastMsg.createdAt).toLocaleTimeString("en-IN", { hour:"2-digit", minute:"2-digit" })}
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <p className="text-sm text-gray-600 truncate">
                      {conv.lastMsg.from === myId ? "You: " : ""}{conv.lastMsg.text}
                    </p>
                    {conv.unread > 0 && (
                      <div className="flex-shrink-0 ml-2 w-5 h-5 bg-emerald-600 text-white text-xs rounded-full flex items-center justify-center">{conv.unread}</div>
                    )}
                  </div>
                </div>
              </button>
            ))}
          </div>
        </div>
      </div>
    );
  }

  // ════════════════════════════════════════════════════════════════
  // CONVERSATION VIEW
  // ════════════════════════════════════════════════════════════════
  return (
    <div className="min-h-screen bg-slate-50 flex flex-col">
      <div className="bg-white shadow-sm sticky top-0 z-10">
        <div className="max-w-4xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <button onClick={() => navigate("/chat")} className="p-2 hover:bg-slate-100 rounded-full transition-colors">
                <ArrowLeft className="w-6 h-6 text-gray-600" />
              </button>
              <div className="flex items-center gap-3">
                <div className="relative">
                  <div className="w-10 h-10 rounded-full bg-gradient-to-br from-emerald-400 to-teal-500 flex items-center justify-center">
                    <User className="w-5 h-5 text-white" />
                  </div>
                  {peerOnline && <div className="absolute bottom-0 right-0 w-3 h-3 bg-green-500 border-2 border-white rounded-full"></div>}
                </div>
                <div>
                  <h2 className="font-semibold text-gray-900">{peerName}</h2>
                  <p className="text-xs text-gray-500">
                    {typing ? "typing..." : peerOnline ? t.online : t.offline}
                  </p>
                </div>
              </div>
            </div>
            <div className="flex gap-2">
              <button className="p-2 hover:bg-slate-100 rounded-full transition-colors"><Phone className="w-5 h-5 text-gray-600" /></button>
              <button className="p-2 hover:bg-slate-100 rounded-full transition-colors"><Video className="w-5 h-5 text-gray-600" /></button>
              <button className="p-2 hover:bg-slate-100 rounded-full transition-colors"><MoreVertical className="w-5 h-5 text-gray-600" /></button>
            </div>
          </div>
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 max-w-4xl w-full mx-auto px-4 py-6 overflow-y-auto">
        {loading && <div className="text-center text-gray-400 mt-8">Loading...</div>}
        {!loading && messages.length === 0 && (
          <p className="text-center text-gray-500 mt-8">{t.noMessages}</p>
        )}
        <div className="space-y-4">
          {messages.map((msg, i) => (
            <div key={msg._id || i} className={`flex ${msg.from === myId ? "justify-end" : "justify-start"}`}>
              <div className={`max-w-[70%] ${msg.from === myId
                  ? "bg-gradient-to-r from-emerald-600 to-teal-600 text-white"
                  : "bg-white text-gray-900"
                } rounded-2xl px-4 py-3 shadow-sm ${msg.optimistic ? "opacity-70" : ""}`}>
                <p className="text-sm">{msg.text}</p>
                <p className={`text-xs mt-1 ${msg.from === myId ? "text-white/70" : "text-gray-500"}`}>
                  {msg.createdAt ? new Date(msg.createdAt).toLocaleTimeString("en-IN", { hour:"2-digit", minute:"2-digit" }) : "sending..."}
                </p>
              </div>
            </div>
          ))}
          {typing && (
            <div className="flex justify-start">
              <div className="bg-white rounded-2xl px-4 py-3 shadow-sm flex gap-1 items-center">
                <span className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{animationDelay:"0ms"}}></span>
                <span className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{animationDelay:"150ms"}}></span>
                <span className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{animationDelay:"300ms"}}></span>
              </div>
            </div>
          )}
          <div ref={messagesEnd} />
        </div>
      </div>

      {/* Input */}
      <div className="bg-white border-t border-gray-200 sticky bottom-0">
        <div className="max-w-4xl mx-auto px-4 py-4">
          <form onSubmit={handleSend} className="flex gap-3">
            <input type="text" value={message} onChange={handleTyping} placeholder={t.typeMessage}
              className="flex-1 px-4 py-3 border border-gray-300 rounded-full focus:outline-none focus:ring-2 focus:ring-emerald-600" />
            <button type="submit" disabled={!message.trim()}
              className="bg-gradient-to-r from-emerald-600 to-teal-600 text-white p-3 rounded-full hover:shadow-lg transition-shadow disabled:opacity-50 disabled:cursor-not-allowed">
              <Send className="w-5 h-5" />
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}
